const { default: makeWASocket, useMultiFileAuthState, DisconnectReason } = require('@whiskeysockets/baileys');
const qrcode = require('qrcode-terminal');
const { GoogleGenAI } = require('@google/genai');
const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

// 🔑 APNI GEMINI API KEY YAHAN PASTE KAREIN
const ai = new GoogleGenAI({ apiKey: "AIzaSyACGTxevKTpW3UgRS8FF6mzWzZjZZ-u8VE" });

const app = express();
const PORT = 3000;

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));

// Data Reading Functions
function getStoreData() {
    try {
        const data = fs.readFileSync(path.join(__dirname, 'storeData.json'), 'utf8');
        return JSON.parse(data || '[]');
    } catch (err) {
        return [];
    }
}

function getSettings() {
    try {
        const data = fs.readFileSync(path.join(__dirname, 'storeSettings.json'), 'utf8');
        return JSON.parse(data || '{}');
    } catch (err) {
        return { storeName: "My Store", deliveryFee: "200", shopTimings: "10am-10pm" };
    }
}

// Dashboard Routes
app.get('/dashboard', (req, res) => {
    const products = getStoreData();
    const settings = getSettings();
    res.render('dashboard', { products, settings });
});

app.post('/add-product', (req, res) => {
    const { name, price, description } = req.body;
    const products = getStoreData();
    products.push({ name, price, description });
    
    fs.writeFileSync(path.join(__dirname, 'storeData.json'), JSON.stringify(products, null, 2));
    res.redirect('/dashboard');
});

app.post('/delete-product', (req, res) => {
    const { index } = req.body;
    let products = getStoreData();
    products.splice(index, 1);
    
    fs.writeFileSync(path.join(__dirname, 'storeData.json'), JSON.stringify(products, null, 2));
    res.redirect('/dashboard');
});

app.post('/update-settings', (req, res) => {
    const { storeName, deliveryFee, shopTimings } = req.body;
    const settings = { storeName, deliveryFee, shopTimings };
    
    fs.writeFileSync(path.join(__dirname, 'storeSettings.json'), JSON.stringify(settings, null, 2));
    res.redirect('/dashboard');
});

app.listen(PORT, () => {
    console.log(`🌐 Admin Dashboard active: http://localhost:${PORT}/dashboard`);
});

// Smart AI Function
async function askAI(userPrompt) {
    try {
        const products = getStoreData();
        const settings = getSettings();
        
        const storeContext = `
            Store Name: ${settings.storeName}
            Delivery Charges: Rs. ${settings.deliveryFee}
            Shop Timings: ${settings.shopTimings}
            Available Products: ${JSON.stringify(products)}
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: userPrompt,
            config: {
                systemInstruction: `Aap ${settings.storeName} ke helpful e-commerce assistant hain. Is store ki live details yeh hain: ${storeContext}. Is information ko follow karte hue customer ko polite aur informative Roman Urdu ya English mein chote jawabat dein.`
            }
        });
        return response.text;
    } catch (error) {
        console.error("AI Error:", error);
        return "Sorry, main abhi process nahi kar pa raha.";
    }
}

// WhatsApp Connection
async function connectToWhatsApp() {
    const { state, saveCreds } = await useMultiFileAuthState('auth_info');

    const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false
    });

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (qr) {
            console.log('\n--- SCAN THIS QR CODE WITH YOUR WHATSAPP ---\n');
            qrcode.generate(qr, { small: true });
        }

        if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            if (shouldReconnect) connectToWhatsApp();
        } else if (connection === 'open') {
            console.log('\n✅ SUCCESS: Upgraded AI Bot & Dashboard LIVE!');
        }
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type === 'notify') {
            for (const msg of messages) {
                if (!msg.key.fromMe && msg.message) {
                    const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
                    const sender = msg.key.remoteJid;

                    if (text) {
                        console.log(`📩 Customer: ${text}`);
                        const aiReply = await askAI(text);
                        await sock.sendMessage(sender, { text: aiReply });
                        console.log(`🤖 AI Reply Sent: ${aiReply}`);
                    }
                }
            }
        }
    });
}

connectToWhatsApp();