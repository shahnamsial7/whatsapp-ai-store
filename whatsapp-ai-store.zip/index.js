'use strict';

// ═══════════════════════════════════════════════════════════════
//  GLOBAL ERROR SHIELDS
// ═══════════════════════════════════════════════════════════════
process.on('uncaughtException',  (err)    => console.error('💥 [uncaughtException]',  err.message));
process.on('unhandledRejection', (reason) => console.error('💥 [unhandledRejection]', reason));

// ═══════════════════════════════════════════════════════════════
//  IMPORTS
// ═══════════════════════════════════════════════════════════════
const Groq        = require('groq-sdk');
const express     = require('express');
const bodyParser  = require('body-parser');
const fs          = require('fs');
const path        = require('path');
const gTTS        = require('gtts');
const ffmpeg      = require('fluent-ffmpeg');
const ffmpegPath  = require('@ffmpeg-installer/ffmpeg').path;
ffmpeg.setFfmpegPath(ffmpegPath);

const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    downloadContentFromMessage
} = require('@whiskeysockets/baileys');
const qrcode = require('qrcode-terminal');

// ═══════════════════════════════════════════════════════════════
//  CONFIGURATION
// ═══════════════════════════════════════════════════════════════
const GROQ_API_KEY    = process.env.GROQ_API_KEY || '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';
const PORT            = process.env.PORT || 3000;
const RAW_ADMIN_PHONE = '923428424445';
const ADMIN_JID       = `${RAW_ADMIN_PHONE}@s.whatsapp.net`;

const DATA_PATH     = path.join(__dirname, 'storeData.json');
const SETTINGS_PATH = path.join(__dirname, 'storeSettings.json');
const ORDERS_PATH   = path.join(__dirname, 'ordersData.json');

const groq = new Groq({ apiKey: GROQ_API_KEY });

// ═══════════════════════════════════════════════════════════════
//  BOT CONNECTION STATE (used by /bot-status route)
// ═══════════════════════════════════════════════════════════════
let botConnected = false;

// ═══════════════════════════════════════════════════════════════
//  CHAT MEMORY MANAGER
// ═══════════════════════════════════════════════════════════════
const MAX_HISTORY     = 12;
const userHistories   = new Map();
const userCarts       = new Map();
const processedMsgIds = new Set();

function getHistory(sender) {
    if (!userHistories.has(sender)) userHistories.set(sender, []);
    return userHistories.get(sender);
}

function pushHistory(sender, role, content) {
    const h = getHistory(sender);
    h.push({ role, content });
    while (h.length > MAX_HISTORY) h.shift();
}

function getCart(sender) {
    if (!userCarts.has(sender)) userCarts.set(sender, []);
    return userCarts.get(sender);
}

function clearCart(sender) {
    userCarts.set(sender, []);
}

// ═══════════════════════════════════════════════════════════════
//  JSON STORAGE HELPERS — all wrapped with try/catch shields
// ═══════════════════════════════════════════════════════════════

// Single source of truth for defaults — was previously duplicated
// verbatim in both the try and catch branches of getSettings(),
// which meant editing one without the other would silently drift.
const DEFAULT_SETTINGS = Object.freeze({
    storeName:          'My Store',
    deliveryFee:        '200',
    shopTimings:        '10am–10pm',
    advancePaymentMode: 'disabled',
    paymentNumber:      '',
    customInstructions: '',
    botTone:            'professional',
    botLanguage:        'urdu',
    paymentAccounts:    { jazzcash: '', easypaisa: '', bankAccount: '', accountTitle: '' }
});

/** Read product list. Returns [] on any error. */
function getStoreData() {
    try {
        const raw = fs.readFileSync(DATA_PATH, 'utf8');
        const parsed = JSON.parse(raw || '[]');
        return Array.isArray(parsed) ? parsed : [];
    } catch { return []; }
}

/** Write product list safely. */
function saveStoreData(products) {
    try {
        fs.writeFileSync(DATA_PATH, JSON.stringify(products, null, 2));
    } catch (e) { console.error('❌ saveStoreData:', e.message); }
}

/** Read settings. Returns full default object on any error. */
function getSettings() {
    try {
        const raw    = fs.readFileSync(SETTINGS_PATH, 'utf8');
        const parsed = JSON.parse(raw || '{}');
        return {
            ...DEFAULT_SETTINGS,
            ...parsed,
            paymentAccounts: { ...DEFAULT_SETTINGS.paymentAccounts, ...(parsed.paymentAccounts || {}) }
        };
    } catch {
        return { ...DEFAULT_SETTINGS, paymentAccounts: { ...DEFAULT_SETTINGS.paymentAccounts } };
    }
}

/** Write settings safely. */
function saveSettings(s) {
    try {
        fs.writeFileSync(SETTINGS_PATH, JSON.stringify(s, null, 2));
    } catch (e) { console.error('❌ saveSettings:', e.message); }
}

/** Read orders list. Returns [] on any error. */
function getOrders() {
    try {
        const raw    = fs.readFileSync(ORDERS_PATH, 'utf8');
        const parsed = JSON.parse(raw || '[]');
        return Array.isArray(parsed) ? parsed : [];
    } catch { return []; }
}

/** Write orders safely. */
function saveOrders(orders) {
    try {
        fs.writeFileSync(ORDERS_PATH, JSON.stringify(orders, null, 2));
    } catch (e) { console.error('❌ saveOrders:', e.message); }
}

/** Append a single new order. */
function appendOrder(orderObj) {
    const orders = getOrders();
    orders.push(orderObj);
    saveOrders(orders);
}

// ═══════════════════════════════════════════════════════════════
//  EXPRESS SETUP
// ═══════════════════════════════════════════════════════════════
const app = express();
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use('/public', express.static(path.join(__dirname, 'public')));

// ─── Dashboard ──────────────────────────────────────────────────
app.get('/dashboard', (req, res) => {
    try {
        const products = getStoreData();
        const orders   = getOrders();

        res.render('dashboard', {
            products,
            settings:      getSettings(),
            orders,
            plans:         getPlans(),
            adminPhone:    '+' + RAW_ADMIN_PHONE,
            rawPhone:      RAW_ADMIN_PHONE,
            botConnected,
            stats: {
                totalProducts: products.length,
                totalOrders:   orders.length,
                pendingOrders: orders.filter(o => o.status === 'pending').length,
                revenue:       orders
                    .filter(o => o.status !== 'cancelled')
                    .reduce((sum, o) => sum + (Number(o.total) || 0), 0)
            }
        });
    } catch (e) {
        console.error('❌ Dashboard render error:', e.message);
        res.status(500).send('Dashboard error: ' + e.message);
    }
});

// ─── Bot Status API (used by dashboard status indicator) ────────
app.get('/bot-status', (req, res) => {
    res.json({ connected: botConnected });
});

// ─── Add Product ────────────────────────────────────────────────
app.post('/add-product', (req, res) => {
    try {
        const { name, price, description, category, stockStatus, imageUrl } = req.body;
        if (!name || !price) return res.redirect('/dashboard?saved=0');

        const products = getStoreData();
        products.push({
            name:        (name || '').trim(),
            price:       (price || '').trim(),
            description: (description || '').trim(),
            category:    (category || '').trim(),
            stockStatus: stockStatus === 'out_of_stock' ? 'out_of_stock' : 'in_stock',
            imageUrl:    (imageUrl || '').trim()
        });
        saveStoreData(products);
        res.redirect('/dashboard?saved=1');
    } catch (e) {
        console.error('❌ add-product:', e.message);
        res.redirect('/dashboard');
    }
});

// ─── Edit Product ────────────────────────────────────────────────
app.post('/edit-product', (req, res) => {
    try {
        const { index, name, price, description, category, stockStatus, imageUrl } = req.body;
        const idx      = parseInt(index, 10);
        const products = getStoreData();

        if (!isNaN(idx) && idx >= 0 && idx < products.length) {
            products[idx] = {
                name:        (name || '').trim(),
                price:       (price || '').trim(),
                description: (description || '').trim(),
                category:    (category || '').trim(),
                stockStatus: stockStatus === 'out_of_stock' ? 'out_of_stock' : 'in_stock',
                imageUrl:    (imageUrl || '').trim()
            };
            saveStoreData(products);
            return res.redirect('/dashboard?saved=1');
        }
        res.redirect('/dashboard?saved=0');
    } catch (e) {
        console.error('❌ edit-product:', e.message);
        res.redirect('/dashboard');
    }
});

// ─── Delete Product ──────────────────────────────────────────────
app.post('/delete-product', (req, res) => {
    try {
        const idx      = parseInt(req.body.index, 10);
        const products = getStoreData();
        if (!isNaN(idx) && idx >= 0 && idx < products.length) {
            products.splice(idx, 1);
            saveStoreData(products);
        }
        res.redirect('/dashboard?saved=1');
    } catch (e) {
        console.error('❌ delete-product:', e.message);
        res.redirect('/dashboard');
    }
});

// ─── Update Store Settings ───────────────────────────────────────
app.post('/update-settings', (req, res) => {
    try {
        const current = getSettings();
        const { storeName, deliveryFee, shopTimings, advancePaymentMode, paymentNumber, customInstructions, botTone, botLanguage } = req.body;
        saveSettings({
            ...current,
            storeName:          (storeName || '').trim(),
            deliveryFee:        (deliveryFee || '').trim(),
            shopTimings:        (shopTimings || '').trim(),
            advancePaymentMode: advancePaymentMode || 'disabled',
            paymentNumber:      (paymentNumber || '').trim(),
            customInstructions: (customInstructions || '').trim(),
            botTone:            botTone || current.botTone || 'professional',
            botLanguage:        botLanguage || current.botLanguage || 'urdu'
        });
        res.redirect('/dashboard?saved=1');
    } catch (e) {
        console.error('❌ update-settings:', e.message);
        res.redirect('/dashboard');
    }
});

// ─── Update Payment Settings ─────────────────────────────────────
app.post('/update-payment', (req, res) => {
    try {
        const current = getSettings();
        const { advancePaymentMode, jazzcash, easypaisa, bankAccount, accountTitle } = req.body;

        const accounts = {
            jazzcash:     (jazzcash     || '').trim(),
            easypaisa:    (easypaisa    || '').trim(),
            bankAccount:  (bankAccount  || '').trim(),
            accountTitle: (accountTitle || '').trim()
        };

        // Build a readable summary for the AI bot to reference
        const paymentNumber = [
            accounts.jazzcash     ? `JazzCash: ${accounts.jazzcash}`   : '',
            accounts.easypaisa    ? `EasyPaisa: ${accounts.easypaisa}` : '',
            accounts.bankAccount  ? `Bank: ${accounts.bankAccount}`     : '',
            accounts.accountTitle ? `(${accounts.accountTitle})`        : ''
        ].filter(Boolean).join(' | ');

        saveSettings({
            ...current,
            advancePaymentMode: advancePaymentMode || 'disabled',
            paymentNumber,
            paymentAccounts:    accounts
        });
        res.redirect('/dashboard?saved=1');
    } catch (e) {
        console.error('❌ update-payment:', e.message);
        res.redirect('/dashboard');
    }
});

// ─── Update AI Agent Settings ────────────────────────────────────
app.post('/update-ai', (req, res) => {
    try {
        const current = getSettings();
        const { botTone, botLanguage, customInstructions } = req.body;
        saveSettings({
            ...current,
            customInstructions: (customInstructions || '').trim(),
            botTone:            botTone || 'professional',
            botLanguage:        botLanguage || 'urdu'
        });
        res.redirect('/dashboard?saved=1');
    } catch (e) {
        console.error('❌ update-ai:', e.message);
        res.redirect('/dashboard');
    }
});

// ─── Update Order Status (AJAX) ──────────────────────────────────
app.post('/update-order-status', (req, res) => {
    try {
        const { index, status } = req.body;
        const idx = parseInt(index, 10);
        const validStatuses = ['pending', 'dispatched', 'delivered', 'cancelled'];

        if (!validStatuses.includes(status)) {
            return res.json({ success: false, error: 'Invalid status' });
        }

        const orders = getOrders();
        if (isNaN(idx) || idx < 0 || idx >= orders.length) {
            return res.json({ success: false, error: 'Order not found' });
        }

        orders[idx].status    = status;
        orders[idx].updatedAt = new Date().toISOString();
        saveOrders(orders);
        res.json({ success: true, status, updatedAt: orders[idx].updatedAt });
    } catch (e) {
        console.error('❌ update-order-status:', e.message);
        res.json({ success: false, error: e.message });
    }
});

// ─── Bot Playground Test ─────────────────────────────────────────
app.post('/playground-test', async (req, res) => {
    try {
        const { message } = req.body;
        if (!message || !message.trim()) return res.json({ reply: '⚠️ Empty message sent.' });

        const reply = await askAI('playground_admin', message.trim());
        res.json({ reply: reply || '⚠️ No response from AI.' });
    } catch (e) {
        console.error('❌ playground-test:', e.message);
        res.json({ reply: '❌ AI error: ' + e.message });
    }
});

// ─── Plans helper ────────────────────────────────────────────────
function getPlans() {
    return [
        { id: 'monthly',   name: 'Monthly Plan',  price: 1500,  duration: '1 Month',  msgs: 'Unlimited' },
        { id: 'quarterly', name: '3-Month Plan',  price: 3000,  duration: '3 Months', msgs: 'Unlimited' },
        { id: 'yearly',    name: 'Yearly Plan',   price: 10000, duration: '1 Year',   msgs: 'Unlimited' }
    ];
}

app.listen(PORT, () =>
    console.log(`🌐 Admin Dashboard → http://localhost:${PORT}/dashboard`)
);

// ═══════════════════════════════════════════════════════════════
//  VOICE — STT (Audio → Urdu Text)
// ═══════════════════════════════════════════════════════════════
async function convertAudioToText(audioBuffer) {
    const tempPath = path.join(__dirname, `stt_${Date.now()}.m4a`);
    try {
        fs.writeFileSync(tempPath, audioBuffer);
        const result = await groq.audio.transcriptions.create({
            file:     fs.createReadStream(tempPath),
            model:    'whisper-large-v3-turbo',
            language: 'ur'
        });
        return result.text || null;
    } catch (err) {
        console.error('❌ STT Error:', err.message);
        return null;
    } finally {
        cleanup(tempPath);
    }
}

// ═══════════════════════════════════════════════════════════════
//  VOICE — TTS (Text → OGG/Opus PTT)
//  Strips WhatsApp markdown so gTTS speaks cleanly
// ═══════════════════════════════════════════════════════════════
function stripMarkdown(text) {
    return text
        .replace(/\*+/g, '')
        .replace(/_+/g, '')
        .replace(/~+/g, '')
        .replace(/```[\s\S]*?```/g, '')
        .replace(/`/g, '')
        .replace(/[•▪◦◆━─]/g, ',')
        .replace(/\n{2,}/g, '. ')
        .replace(/\n/g, ', ')
        .trim();
}

async function convertTextToAudio(text) {
    const cleanText = stripMarkdown(text);
    const tempMp3   = path.join(__dirname, `tts_${Date.now()}.mp3`);
    const tempOgg   = path.join(__dirname, `tts_${Date.now()}.opus`);

    return new Promise((resolve, reject) => {
        try {
            const gtts = new gTTS(cleanText, 'ur');
            gtts.save(tempMp3, (err) => {
                if (err) { cleanup(tempMp3); return reject(err); }

                ffmpeg(tempMp3)
                    .audioCodec('libopus')
                    .audioBitrate('32k')
                    .audioFrequency(16000)
                    .toFormat('ogg')
                    .on('end', () => {
                        const buf = fs.readFileSync(tempOgg);
                        cleanup(tempMp3, tempOgg);
                        resolve(buf);
                    })
                    .on('error', (e) => { cleanup(tempMp3, tempOgg); reject(e); })
                    .save(tempOgg);
            });
        } catch (e) { cleanup(tempMp3, tempOgg); reject(e); }
    });
}

// ═══════════════════════════════════════════════════════════════
//  CART UTILITIES
// ═══════════════════════════════════════════════════════════════
function buildCartSummary(sender, deliveryFee) {
    const cart = getCart(sender);
    if (!cart.length) return null;

    let subtotal = 0;
    const lines  = cart.map((item, i) => {
        const lineTotal = item.price * item.qty;
        subtotal += lineTotal;
        return `  ${i + 1}. ${item.name} × ${item.qty} = Rs. ${lineTotal}`;
    });

    const fee   = parseInt(deliveryFee, 10) || 0;
    const total = subtotal + fee;

    return (
        `🛒 *Cart Summary*\n` +
        lines.join('\n') + '\n' +
        `━━━━━━━━━━━━━━\n` +
        `📦 Subtotal : Rs. ${subtotal}\n` +
        `🚚 Delivery : Rs. ${fee}\n` +
        `💰 *Total   : Rs. ${total}*`
    );
}

// ═══════════════════════════════════════════════════════════════
//  AI ENGINE
// ═══════════════════════════════════════════════════════════════

/** Build a tone instruction string based on admin setting */
function getToneInstruction(tone) {
    const tones = {
        professional: 'Aap professional, formal, aur respectful andaaz mein baat karein.',
        friendly:     'Aap friendly, casual, aur warm andaaz mein baat karein jaise dost se baat ho rahi ho.',
        aggressive:   'Aap ek energetic sales expert ki tarah baat karein. Offers highlight karein, urgency create karein, aur customer ko jaldi order karne ke liye motivate karein.'
    };
    return tones[tone] || tones.professional;
}

/** Build a language instruction string based on admin setting */
function getLanguageInstruction(lang) {
    const langs = {
        urdu:    'Sirf Urdu ya Roman Urdu mein jawab dein.',
        english: 'Reply only in English.',
        both:    'Detect customer ki language (Urdu ya English) aur usi mein reply karein.'
    };
    return langs[lang] || langs.urdu;
}

/**
 * Detects a fabricated "AI busy / retry in X seconds" style message.
 * The model has no real awareness of rate limits or timers — if it ever
 * produces text like this it's a hallucination, and a dangerous one:
 * pushHistory() would save it as a real assistant turn, and every future
 * call for that customer would see it in context and keep imitating/
 * escalating it (this is what produces repeating countdown messages
 * with a different number each time — 52s, 39s, 21s...).
 * We treat any match as a failed generation: never send it, never store it.
 */
function looksLikeFabricatedBusyMessage(text) {
    if (!text) return false;
    return /\b(AI|assistant)\b[^.\n]{0,20}\bbusy\b[^.\n]{0,40}\b(second|seconds)\b/i.test(text)
        || /\bdobara\s+try\s+karein\b/i.test(text)
        || /\b\d{1,3}\s*seconds?\s+m(ei|e)n\s+dobara\b/i.test(text);
}

/**
 * Parses a "retry in Xs" hint out of a Groq rate-limit (429) error message,
 * so we can actually wait the real amount of time instead of a blind delay
 * that's almost always too short to matter. Capped so one slow customer
 * message can't block the event loop for a full minute.
 */
function parseRetryAfterMs(err) {
    const msg = err?.error?.message || err?.message || '';
    const match = msg.match(/try again in ([\d.]+)s/i);
    if (!match) return null;
    const seconds = parseFloat(match[1]);
    if (!isFinite(seconds)) return null;
    return Math.min(Math.max(seconds, 1), 8) * 1000; // clamp 1s–8s
}

async function askAI(sender, userPrompt, retries = 2) {
    try {
        const products     = getStoreData();
        const settings     = getSettings();
        const cartItems    = getCart(sender);
        const cartSummary  = buildCartSummary(sender, settings.deliveryFee);

        const storeContext = [
            `🏪 Store     : ${settings.storeName}`,
            `🚚 Delivery  : Rs. ${settings.deliveryFee}`,
            `🕐 Timings   : ${settings.shopTimings}`,
            `📞 Admin     : +${RAW_ADMIN_PHONE}`,
            `💳 Payment   : ${settings.advancePaymentMode === 'disabled' ? 'COD only' : `Advance via ${settings.paymentNumber}`}`,
            ``,
            `📦 PRODUCTS:`,
            ...products.map((p, i) =>
                `  ${i + 1}. ${p.name}${p.category ? ` [${p.category}]` : ''} — Rs. ${p.price}` +
                (p.stockStatus === 'out_of_stock' ? ' ❌ OUT OF STOCK' : ' ✅') +
                (p.description ? ` — ${p.description}` : '')
            )
        ].join('\n');

        const cartContext = cartItems.length
            ? `\n\n🛒 CUSTOMER CART:\n${cartSummary}`
            : '\n\n🛒 CART: Empty';

        const systemPrompt = `
Aap ${settings.storeName} ke AI Sales Assistant hain.

TONE: ${getToneInstruction(settings.botTone)}
LANGUAGE: ${getLanguageInstruction(settings.botLanguage)}

━━━ STORE INFO ━━━
${storeContext}${cartContext}

━━━ ADMIN CUSTOM INSTRUCTIONS ━━━
${settings.customInstructions || 'None'}

━━━ MESSAGE FORMATTING ━━━
• WhatsApp messages — short & crisp (max 6 lines)
• Use *bold* for product names and prices
• Use emojis naturally — not excessively
• Bullets for lists, no walls of text
• NEVER repeat greetings if conversation already started
• NEVER mention SaaS or subscription plans to customers
• Out of Stock items — inform customer and suggest alternatives

━━━ MULTI-PRODUCT CART RULES ━━━
• Customer ek se zyada products order kar sakta hai
• Jab customer koi product add kare, reply mein CART_UPDATE tag include karein:
  <<<CART_UPDATE: Product="Name", Price=PRICE_NUMBER, Qty=1>>>
• Cart update ke baad updated cart summary bhi customer ko dikhayein
• Customer "done", "confirm", "order confirm", "bas yahi", ya "thak gaya" kahe tab order process karein

━━━ ORDER CONFIRMATION ━━━
• Sirf tab confirm karein jab yeh 4 details collect ho jayein:
  1️⃣ Customer Full Name
  2️⃣ Complete Delivery Address
  3️⃣ Google Maps Link
  4️⃣ Secondary Phone Number
• Sab mil jayein to response ke BILKUL END mein SIRF EK BAAR likhein:
  <<<ORDER_CONFIRMED: Cart=CART_JSON, Name="Full Name", Address="Address", Location="Map Link", Phone="Alt Phone">>>
• ORDER_CONFIRMED ke baad clean confirmation bhi dikhayein

━━━ ERROR HANDLING ━━━
• Agar samajh na aaye, politely clarify poochein
• Koi bhi fallback message repeat mat karein
• Aap kabhi bhi "AI busy hai", "X seconds mein dobara try karein", ya koi
  bhi fake system/waiting/timer message NAHI banayenge. Aap ko rate-limit
  ya system status ka pata hi nahi hota — yeh sirf app khud handle karta hai.
  Agar aap kuch samajh nahi paa rahe, seedha politely poochein — kabhi
  koi jhoota "busy" ya countdown message mat likhein.
`.trim();

        pushHistory(sender, 'user', userPrompt);

        const completion = await groq.chat.completions.create({
            model:       'llama-3.3-70b-versatile',
            messages:    [{ role: 'system', content: systemPrompt }, ...getHistory(sender)],
            temperature: 0.5,
            max_tokens:  600
        });

        let reply = completion.choices[0]?.message?.content?.trim() || null;

        // Never let a hallucinated "busy/countdown" reply reach the customer
        // or get written into history — one bad turn in history is what
        // causes the model to keep imitating it on every later message.
        if (reply && looksLikeFabricatedBusyMessage(reply)) {
            console.error(`⚠️ Discarded fabricated "busy" reply for [${sender}]:`, reply);
            reply = null;
        }

        if (reply) pushHistory(sender, 'assistant', reply);
        return reply;

    } catch (err) {
        const status    = err?.status || err?.response?.status;
        const isRateLim = status === 429 || /rate.?limit/i.test(err?.message || '');
        console.error(`❌ AI Error${isRateLim ? ' (rate limited)' : ''}:`, err.message || err);

        if (retries > 0) {
            const delay = (isRateLim && parseRetryAfterMs(err)) || 1500;
            await sleep(delay);
            return askAI(sender, userPrompt, retries - 1);
        }
        // Exhausted retries — return null so the caller sends the one
        // clean, hardcoded fallback message instead of anything the
        // model or the raw API error produced.
        return null;
    }
}

// ═══════════════════════════════════════════════════════════════
//  UTILITY HELPERS
// ═══════════════════════════════════════════════════════════════
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

function cleanup(...files) {
    for (const f of files) {
        try { if (fs.existsSync(f)) fs.unlinkSync(f); } catch (_) {}
    }
}

/** Process CART_UPDATE tags — mutate cart, return cleaned reply */
function processCartUpdates(sender, reply) {
    const tagRegex = /<<<CART_UPDATE:\s*Product="([^"]+)",\s*Price=(\d+),\s*Qty=(\d+)>>>/g;
    let match;
    while ((match = tagRegex.exec(reply)) !== null) {
        const [, productName, priceStr, qtyStr] = match;
        const price    = parseInt(priceStr, 10);
        const qty      = parseInt(qtyStr,   10) || 1;
        const cart     = getCart(sender);
        const existing = cart.find(i => i.name.toLowerCase() === productName.toLowerCase());
        if (existing) {
            existing.qty += qty;
        } else {
            cart.push({ name: productName, price, qty });
        }
        console.log(`🛒 Cart [${sender}]: +${qty}× ${productName}`);
    }
    return reply.replace(tagRegex, '').trim();
}

/** Extract ORDER_CONFIRMED tag from reply */
function extractOrderTag(reply) {
    const tagRegex = /<<<ORDER_CONFIRMED:[\s\S]*?>>>/;
    const match    = reply.match(tagRegex);
    if (!match) return { cleanReply: reply, orderTag: null };
    const orderTag   = match[0];
    const cleanReply = reply.replace(orderTag, '').replace(/\n{3,}/g, '\n\n').trim();
    return { cleanReply, orderTag };
}

/**
 * Parse ORDER_CONFIRMED tag into a structured object.
 * NOTE: the Cart=[...] capture is greedy up to the last `]` on the
 * line rather than lazy — a lazy match would truncate early if a
 * product name inside the JSON itself contains a `]` character.
 */
function parseOrderTag(sender, orderTag) {
    try {
        const inner    = orderTag.replace('<<<ORDER_CONFIRMED:', '').replace(/>>>\s*$/, '').trim();
        const cartMatch = inner.match(/Cart=(\[[\s\S]*\])(?=,\s*Name=)/);
        const cartArr   = cartMatch ? JSON.parse(cartMatch[1]) : getCart(sender);

        const getName     = inner.match(/Name="([^"]*)"/);
        const getAddress  = inner.match(/Address="([^"]*)"/);
        const getLocation = inner.match(/Location="([^"]*)"/);
        const getPhone    = inner.match(/Phone="([^"]*)"/);

        const settings = getSettings();
        const fee      = parseInt(settings.deliveryFee, 10) || 0;
        const subtotal = cartArr.reduce((s, i) => s + (Number(i.price) || 0) * (Number(i.qty) || 1), 0);

        return {
            phone:        sender.replace(/@s\.whatsapp\.net$/, ''),
            customerName: getName     ? getName[1]     : '',
            address:      getAddress  ? getAddress[1]  : '',
            location:     getLocation ? getLocation[1] : '',
            altPhone:     getPhone    ? getPhone[1]    : '',
            cart:         cartArr,
            subtotal,
            deliveryFee:  fee,
            total:        subtotal + fee,
            status:       'pending',
            createdAt:    new Date().toISOString()
        };
    } catch (e) {
        console.error('❌ parseOrderTag:', e.message);
        return null;
    }
}

/** Build clean admin WhatsApp notification */
function buildAdminNotification(orderData) {
    if (!orderData) return null;
    const cartLines = orderData.cart.map(i =>
        `  • ${i.name} × ${i.qty || 1} = Rs. ${(i.price || 0) * (i.qty || 1)}`
    ).join('\n');

    return (
        `🚨 *NEW ORDER RECEIVED!* 🚨\n\n` +
        `👤 *Name    :* ${orderData.customerName || '—'}\n` +
        `📱 *Number  :* +${orderData.phone}\n` +
        `📞 *Alt No  :* ${orderData.altPhone || '—'}\n` +
        `📍 *Address :* ${orderData.address || '—'}\n` +
        `🗺  *Map     :* ${orderData.location || '—'}\n\n` +
        `🛒 *Items:*\n${cartLines}\n\n` +
        `📦 Subtotal : Rs. ${orderData.subtotal}\n` +
        `🚚 Delivery : Rs. ${orderData.deliveryFee}\n` +
        `💰 *Total   : Rs. ${orderData.total}*\n\n` +
        `✅ Confirmed by AI Bot — please process delivery!`
    );
}

/** Send text message — centralised to avoid duplicate sends */
async function sendText(sock, jid, text) {
    try { await sock.sendMessage(jid, { text }); }
    catch (e) { console.error(`❌ sendText [${jid}]:`, e.message); }
}

// ═══════════════════════════════════════════════════════════════
//  WHATSAPP CONNECTION
// ═══════════════════════════════════════════════════════════════
let isConnecting = false;

async function connectToWhatsApp() {
    if (isConnecting) return;
    isConnecting = true;

    try {
        const { version }          = await fetchLatestBaileysVersion();
        const { state, saveCreds } = await useMultiFileAuthState('auth_info');

        const sock = makeWASocket({
            version,
            auth:              state,
            printQRInTerminal: false,
            syncFullHistory:   false,
            logger: {
                level: 'silent',
                trace: ()=>{}, debug: ()=>{}, info: ()=>{},
                warn:  ()=>{}, error: ()=>{}, child: function () { return this; }
            }
        });

        // ── Connection lifecycle ─────────────────────────────────
        sock.ev.on('connection.update', ({ connection, lastDisconnect, qr }) => {
            if (qr) {
                console.log('\n──── SCAN WITH WHATSAPP ────');
                qrcode.generate(qr, { small: true });
            }
            if (connection === 'open') {
                console.log('✅ WhatsApp bot connected!');
                botConnected = true;
                isConnecting = false;
            }
            if (connection === 'close') {
                botConnected = false;
                isConnecting = false;
                const code   = lastDisconnect?.error?.output?.statusCode;
                if (code === DisconnectReason.loggedOut) {
                    console.log('⚠️  Logged out. Delete auth_info folder and restart.');
                    return;
                }
                console.log('🔄 Reconnecting in 5s…');
                setTimeout(connectToWhatsApp, 5000);
            }
        });

        sock.ev.on('creds.update', saveCreds);

        // ── Incoming messages ────────────────────────────────────
        sock.ev.on('messages.upsert', async ({ messages: msgs, type }) => {
            if (type !== 'notify') return;

            for (const msg of msgs) {
                if (msg.key.fromMe || !msg.message) continue;

                // Deduplication
                const msgId = msg.key.id;
                if (processedMsgIds.has(msgId)) continue;
                processedMsgIds.add(msgId);
                if (processedMsgIds.size > 1000) processedMsgIds.clear();

                const sender   = msg.key.remoteJid;
                let   userText = null;
                let   isVoice  = false;

                // Extract text
                if (msg.message.conversation) {
                    userText = msg.message.conversation;
                } else if (msg.message.extendedTextMessage?.text) {
                    userText = msg.message.extendedTextMessage.text;
                }

                // Handle voice messages
                if (msg.message.audioMessage) {
                    isVoice = true;
                    try {
                        const stream = await downloadContentFromMessage(msg.message.audioMessage, 'audio');
                        let buf = Buffer.from([]);
                        for await (const chunk of stream) buf = Buffer.concat([buf, chunk]);

                        userText = await convertAudioToText(buf);
                        if (userText) {
                            console.log(`🎙️ STT [${sender}]: ${userText}`);
                        } else {
                            await sendText(sock, sender, '⚠️ آواز سمجھ نہیں آئی، براہ کرم دوبارہ بولیں یا ٹیکسٹ کریں۔');
                            continue;
                        }
                    } catch (audioErr) {
                        console.error('❌ Audio error:', audioErr.message);
                        continue;
                    }
                }

                if (!userText) continue;
                console.log(`📩 [${sender}]: ${userText}`);

                // Get AI reply
                let aiReply = null;
                try { aiReply = await askAI(sender, userText); }
                catch (e) { console.error('❌ AI call failed:', e.message); }

                // If AI returns nothing — one clean error, then skip
                if (!aiReply) {
                    await sendText(sock, sender, '⚠️ ابھی جواب دینے میں دشواری ہے، تھوڑی دیر بعد دوبارہ کوشش کریں۔');
                    continue;
                }

                // Process CART_UPDATE tags
                let processedReply = processCartUpdates(sender, aiReply);

                // Process ORDER_CONFIRMED tag
                const { cleanReply, orderTag } = extractOrderTag(processedReply);

                if (orderTag) {
                    const orderData = parseOrderTag(sender, orderTag);
                    if (orderData) {
                        // Save to orders file
                        appendOrder(orderData);
                        console.log(`✅ Order saved to orders log.`);

                        // Notify admin
                        try {
                            const adminMsg = buildAdminNotification(orderData);
                            if (adminMsg) {
                                await sock.sendMessage(ADMIN_JID, { text: adminMsg });
                                console.log('✅ Admin notified via WhatsApp.');
                            }
                        } catch (adminErr) {
                            console.error('❌ Admin notify failed:', adminErr.message);
                        }
                        clearCart(sender);
                    }
                }

                const replyText = cleanReply || processedReply;

                // Send reply to customer
                if (isVoice) {
                    try {
                        const audioBuffer = await convertTextToAudio(replyText);
                        await sock.sendMessage(sender, {
                            audio:    audioBuffer,
                            mimetype: 'audio/ogg; codecs=opus',
                            ptt:      true
                        });
                        console.log(`🔊 Voice reply → [${sender}]`);
                    } catch (ttsErr) {
                        console.error('❌ TTS failed, sending text fallback:', ttsErr.message);
                        await sendText(sock, sender, replyText);
                    }
                } else {
                    await sendText(sock, sender, replyText);
                    console.log(`💬 Text reply → [${sender}]`);
                }
            }
        });

    } catch (initErr) {
        console.error('❌ Connection init error:', initErr.message);
        botConnected = false;
        isConnecting = false;
        setTimeout(connectToWhatsApp, 10000);
    }
}

// ═══════════════════════════════════════════════════════════════
//  BOOT
// ═══════════════════════════════════════════════════════════════
connectToWhatsApp();